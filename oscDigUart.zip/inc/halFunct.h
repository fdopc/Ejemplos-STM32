#include "stm32f4xx.h"
#include "stm32f4xx_usart.h"
#include "stm32f4xx_dma.h"
#include "stm32f4xx_adc.h"
#include "stm32f429i_discovery_lcd.h"

  #define FONTSIZE         Font12x12

void USART_Config(void);
void sendBlockDMA(uint8_t *data, uint16_t size);
void schmitt_trigger(uint16_t level, uint16_t hyst);
void TIM2_Config(void);
void Display_Init(void);
